# NxbLesson05Views

Project ASP.NET Core MVC .NET 8 dựng lại theo video Lesson05 - Views I.

Các phần chính trong video được tái hiện:
- MVC Views cơ bản và Layout/ViewStart
- Truyền dữ liệu Razor trực tiếp trong View
- Trang thông tin sinh viên
- Cú pháp Razor: inline expression, block code, if/else, for và mảng/foreach
- Ví dụ Bootstrap/HTML hiển thị trong View

Thay đổi theo yêu cầu: mọi chuỗi/tên dự án/namespace chứa `Tvc` đã đổi thành `Nxb`.
